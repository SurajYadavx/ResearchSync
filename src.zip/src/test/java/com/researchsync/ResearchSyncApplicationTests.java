package com.researchsync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResearchSyncApplicationTests {

    @Test
    void contextLoads() {
        // Test passes if application loads
    }
}
