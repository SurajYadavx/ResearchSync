// ResearchSync Custom JavaScript
