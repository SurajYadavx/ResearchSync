package com.researchsync.controller;

import com.researchsync.model.UploadedFile;
import com.researchsync.model.User;
import com.researchsync.model.Workspace;
import com.researchsync.service.FileService;
import com.researchsync.service.UserService;
import com.researchsync.service.WorkspaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/files")
public class FileController {

    @Autowired
    private FileService fileService;

    @Autowired
    private UserService userService;

    @Autowired
    private WorkspaceService workspaceService;

    // UPLOAD FILE FORM - FIXED
    @GetMapping("/upload")
    public String uploadForm(@RequestParam(required = false) Long workspaceId,
                             @AuthenticationPrincipal UserDetails userDetails,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        try {
            User currentUser = userService.findByEmail(userDetails.getUsername());

            List<Workspace> userWorkspaces = workspaceService.getUserWorkspaces(currentUser);
            model.addAttribute("workspaces", userWorkspaces);
            model.addAttribute("selectedWorkspaceId", workspaceId);

            return "files/upload";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMsg", "Error loading upload form: " + e.getMessage());
            return "redirect:/dashboard";
        }
    }

    // UPLOAD FILE - FIXED WITH CATEGORIES
    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file,
                             @RequestParam Long workspaceId,
                             @RequestParam String category,
                             @RequestParam(required = false) String description,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes redirectAttributes) {
        try {
            if (file.isEmpty()) {
                redirectAttributes.addFlashAttribute("errorMsg", "Please select a file to upload.");
                return "redirect:/files/upload?workspaceId=" + workspaceId;
            }

            User uploader = userService.findByEmail(userDetails.getUsername());

            if (!workspaceService.canUserAccessWorkspace(uploader, workspaceId)) {
                redirectAttributes.addFlashAttribute("errorMsg", "You don't have access to this workspace.");
                return "redirect:/dashboard";
            }

            Workspace workspace = workspaceService.findById(workspaceId);

            UploadedFile uploadedFile = fileService.uploadFileWithCategory(file, workspace, uploader, category, description);

            redirectAttributes.addFlashAttribute("successMsg",
                    "File '" + uploadedFile.getOriginalFilename() + "' uploaded successfully!");

            return "redirect:/workspace/" + workspaceId;

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMsg",
                    "Failed to upload file: " + e.getMessage());
            return "redirect:/files/upload?workspaceId=" + workspaceId;
        }
    }

    // DOWNLOAD FILE
    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId,
                                                 @AuthenticationPrincipal UserDetails userDetails) {
        try {
            User currentUser = userService.findByEmail(userDetails.getUsername());
            UploadedFile file = fileService.findById(fileId);

            if (!workspaceService.canUserAccessWorkspace(currentUser, file.getWorkspace().getWorkspaceId())) {
                return ResponseEntity.notFound().build();
            }

            Resource resource = fileService.downloadFile(fileId);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + file.getOriginalFilename() + "\"")
                    .body(resource);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
