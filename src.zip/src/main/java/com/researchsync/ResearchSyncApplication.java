package com.researchsync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResearchSyncApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResearchSyncApplication.class, args);
    }
}
