package com.researchsync.service;

import com.researchsync.model.UploadedFile;
import com.researchsync.model.User;
import com.researchsync.model.Workspace;
import com.researchsync.repository.UploadedFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class FileService {

    @Autowired
    private UploadedFileRepository uploadedFileRepository;

    @Autowired
    private WorkspaceService workspaceService;

    @Value("${app.upload.dir:./uploads/}")
    private String uploadDir;

    // UPLOAD FILE WITH CATEGORY
    public UploadedFile uploadFileWithCategory(MultipartFile file, Workspace workspace, User uploader, String category, String description) {
        try {
            // Create upload directory if it doesn't exist
            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // Generate unique filename
            String originalFilename = file.getOriginalFilename();
            String fileExtension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String uniqueFilename = UUID.randomUUID().toString() + fileExtension;

            // Save file to disk
            Path filePath = uploadPath.resolve(uniqueFilename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // Create file record
            UploadedFile uploadedFile = new UploadedFile();
            uploadedFile.setFilename(uniqueFilename);
            uploadedFile.setOriginalFilename(originalFilename);
            uploadedFile.setDescription(description);
            uploadedFile.setCategory(category);
            uploadedFile.setContentType(file.getContentType());
            uploadedFile.setFileSize(file.getSize());
            uploadedFile.setFilePath(filePath.toString());
            uploadedFile.setWorkspace(workspace);
            uploadedFile.setUploadedBy(uploader);
            uploadedFile.setUploadedDate(LocalDateTime.now());

            return uploadedFileRepository.save(uploadedFile);

        } catch (IOException e) {
            throw new RuntimeException("Failed to upload file: " + e.getMessage());
        }
    }

    // LEGACY METHOD FOR BACKWARD COMPATIBILITY
    public UploadedFile uploadFile(MultipartFile file, Workspace workspace, User uploader, String description) {
        return uploadFileWithCategory(file, workspace, uploader, "Other", description);
    }

    // GET FILES UPLOADED BY A USER
    public List<UploadedFile> getUserFiles(User user) {
        return uploadedFileRepository.findByUploadedByAndIsActiveTrue(user);
    }


    // FIND FILE BY ID
    public UploadedFile findById(Long fileId) {
        return uploadedFileRepository.findById(fileId)
                .orElseThrow(() -> new RuntimeException("File not found with ID: " + fileId));
    }

    // GET WORKSPACE FILES BY CATEGORY
    public List<UploadedFile> getWorkspaceFilesByCategory(Long workspaceId, String category) {
        Workspace workspace = workspaceService.findById(workspaceId);
        return uploadedFileRepository.findByWorkspaceAndCategoryAndIsActiveTrue(workspace, category);
    }

    // GET WORKSPACE FILES
    public List<UploadedFile> getWorkspaceFiles(Long workspaceId) {
        Workspace workspace = workspaceService.findById(workspaceId);
        return uploadedFileRepository.findByWorkspaceAndIsActiveTrueOrderByUploadedDateDesc(workspace);
    }

    // DOWNLOAD FILE
    public Resource downloadFile(Long fileId) {
        try {
            UploadedFile file = findById(fileId);
            Path filePath = Paths.get(file.getFilePath());
            Resource resource = new UrlResource(filePath.toUri());

            if (resource.exists() && resource.isReadable()) {
                return resource;
            } else {
                throw new RuntimeException("File not found or not readable");
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to download file: " + e.getMessage());
        }
    }

    // DELETE FILE
    public void deleteFile(Long fileId, User deleter) {
        try {
            UploadedFile file = findById(fileId);

            // Check permissions
            if (!file.getUploadedBy().getUserId().equals(deleter.getUserId()) &&
                    !workspaceService.isUserAdminOfWorkspace(deleter, file.getWorkspace().getWorkspaceId())) {
                throw new RuntimeException("You don't have permission to delete this file");
            }

            // Mark as inactive instead of deleting
            file.setActive(false);
            uploadedFileRepository.save(file);

            // Optionally delete from disk
            try {
                Files.deleteIfExists(Paths.get(file.getFilePath()));
            } catch (IOException e) {
                System.err.println("Warning: Failed to delete file from disk: " + e.getMessage());
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to delete file: " + e.getMessage());
        }
    }

    // GET FILES BY CATEGORY
    public List<UploadedFile> getFilesByCategory(String category) {
        return uploadedFileRepository.findByCategoryAndIsActiveTrueOrderByUploadedDateDesc(category);
    }

    // SEARCH FILES
    public List<UploadedFile> searchFiles(String searchTerm) {
        return uploadedFileRepository.findByOriginalFilenameContainingIgnoreCaseAndIsActiveTrue(searchTerm);
    }
}
